import javax.swing.*;

public class ColorViewer
{
   public static void main(String[] args)
   {
       JFrame frame = new ColorFrame();
       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       frame.setTitle("Color");
       frame.setVisible(true);
      
   }
}