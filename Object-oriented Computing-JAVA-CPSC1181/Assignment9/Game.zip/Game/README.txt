In the game there are 19 cards with smile(unselected card) and 1 card with the image game over that is the looser piece.
